# Project 4.3 OPT.6–8 analytical verification

Sol job **2352769** completed with exit code 0. The six analytical tests passed in 0.056 s. Its exact stdout and machine-readable KKT report are in `Project43_OPT678_slurm-2352769.out` and `Project43_OPT678_verification.json`.

Source paths in the repository are `project4_fem/project43_optimizer.py`, `project4_fem/project43_optimality.py`, and `project4_fem/test_project43_optimizer.py`. The staged Sol copy and outputs are under `/scratch/jtfoste6/opt678-analytical/`.

The normalized analytical optimum was (0.3749999999999995, 0.6249999999999989), with objective 1.1712500000000008, side share 0.499 and nominal area 83 mm². The independent NNLS audit recovered multipliers (0.13750000000000012, 0, 0.2000000000000015) for the three constraints, with all bound multipliers zero. Primal and dual violations were zero. Stationarity infinity norm was 2.22e-16 and complementarity infinity norm was 3.11e-16. The share lower bound and area bound were active at tolerance 1e-6. SLSQP reported success after two unique design evaluations.

The response adapter requires a positive finite power, a side share, physical derivatives with respect to (h_mm, s_mm), and `converged=True`. It caches exactly matching normalized points and raises on invalid or unconverged responses. SLSQP uses its internal Hessian approximation, ftol=1e-10 and maxiter=35. The KKT audit is independent of SLSQP's success flag.

This verifies an analytical response only. It does not establish a turbulent adjoint, a converged SST forward state, or a turbulent optimum. The live local package did not contain `lam_pair.py`; its preserved source and conventions were available in the project evidence and technical handoff. No frozen source or CFD implementation changed.
